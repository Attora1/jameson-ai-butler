// TetherCanvas.jsx (Final Reflection + Smooth Close)
import React, { useRef, useEffect, useState } from 'react';
import '../styles/modes-css/tether.css';
import { HeartShape, SpiralShape, FlowerShape } from '../utils/tetherShapes.jsx';

export default function TetherCanvas({ onComplete }) {
  const canvasRef = useRef(null);
  const orbsRef = useRef([]);
  const [isComplete, setIsComplete] = useState(false);
  const [orbsCollected, setOrbsCollected] = useState(0);
  const [showIntro, setShowIntro] = useState(true);
  const [showReflection, setShowReflection] = useState(false);
  const [reflectionText, setReflectionText] = useState('');
  const [playerMode, setPlayerMode] = useState('single');
  const chimeAudio = useRef(null);
  const [isClosing, setIsClosing] = useState(false);



  const shapes = [<HeartShape />, <FlowerShape />, <SpiralShape />];
  const [currentShapeIndex, setCurrentShapeIndex] = useState(0);
  const shapeSettings = [
    { shape: <HeartShape />, orbs: 20, speed: 1.5 },
    { shape: <FlowerShape />, orbs: 15, speed: 1 },
    { shape: <SpiralShape />, orbs: 10, speed: 0.5 }
  ];

  useEffect(() => {
    const savedIndex = parseInt(localStorage.getItem('tetherShapeIndex')) || 0;
    setCurrentShapeIndex(savedIndex);
  }, []);

  useEffect(() => {
    if (isComplete) {
      const nextIndex = (currentShapeIndex + 1) % shapes.length;
      localStorage.setItem('tetherShapeIndex', nextIndex.toString());
    }
  }, [isComplete]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return; // ✅ prevent null access
    const ctx = canvas.getContext('2d');
    let animationFrameId;

    const resizeCanvas = () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const settings = shapeSettings[currentShapeIndex];

    orbsRef.current = Array.from({ length: settings.orbs }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: 10,
        color: ['#4c17c75d', '#eb37a958', '#eda14556'][Math.floor(Math.random() * 3)],
        collected: false,
        speed: settings.speed * (0.5 + Math.random())
    }));

    const draw = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        orbsRef.current.forEach(orb => {
            if (!orb.collected) {
                orb.y += orb.speed;
                if (orb.y > canvas.height) orb.y = -orb.r;
                ctx.beginPath();
                ctx.arc(orb.x, orb.y, orb.r, 0, Math.PI * 2);
                ctx.fillStyle = orb.color;
                ctx.fill();
            }
        });
        animationFrameId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
        window.removeEventListener('resize', resizeCanvas);
        cancelAnimationFrame(animationFrameId);
    };
}, [currentShapeIndex]);


  const handleClick = (e) => {
    if (showIntro || isComplete) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const scaleX = canvasRef.current.width / rect.width;
    const scaleY = canvasRef.current.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    for (let orb of orbsRef.current) {
      if (!orb.collected && Math.hypot(orb.x - x, orb.y - y) < orb.r + 5) {
        orb.collected = true;
        setOrbsCollected(prev => {
          const updated = prev + 1;
          if (updated >= shapeSettings[currentShapeIndex].orbs && !isComplete) {
            setIsComplete(true);
            chimeAudio.current = new Audio('/sounds/tether-chime.mp3');
            chimeAudio.current.play().catch(() => {});
          }
          return updated;
        });
        break;
      }
    }
  };

  const handleReflectionSave = () => {
    console.log('Reflection saved:', reflectionText);
    const modal = document.querySelector('.tether-modal');
    if (modal) {
      modal.classList.add('hide');
      setTimeout(() => {
        if (onComplete) onComplete();
      }, 600);
    } else {
      if (onComplete) onComplete();
    }
  };

  const handleClose = () => {
    setIsClosing(true);
    if (tetherAudio.current) {
      tetherAudio.current.pause();
      tetherAudio.current = null;
    }
    setTimeout(() => {
      setIsComplete(false);
      setIsClosing(false);
      if (onComplete) onComplete();
    }, 600); // match transition

    const closeIntroModal = () => {
        setIsClosingIntro(true);
        setTimeout(() => {
            setShowIntro(false);
            setIsClosingIntro(false);
        }, 600); // match CSS transition
    };
    
    return (
        <div className="tether-canvas-wrapper">
            <canvas ref={canvasRef} className="tether-canvas" onClick={handleClick}></canvas>
    
            {showIntro && (
                <div className={`tether-modal ${!isClosingIntro ? 'show' : 'hide'}`}>
                    <div className="tether-modal-content">
                        <h3>✨ Tether Together ✨</h3>
                        <p>Guide the lines to collect orbs. Choose your mode:</p>
                        <div className="tether-player-select">
                            <button onClick={() => { setPlayerMode('single'); closeIntroModal(); }}>Single Player</button>
                            <button onClick={() => { setPlayerMode('dual'); closeIntroModal(); }}>Two Players</button>
                        </div>
                        <button onClick={() => { closeIntroModal(); onComplete(); }}>Exit</button>
                    </div>
                </div>
            )}

      {isComplete && !showReflection && (
        <div className={`tether-modal ${isComplete && !isClosing ? 'show' : 'hide'}`}>
  <div className="tether-modal-content">
    <p>✨ You've Tethered! Take a breath here together. ✨</p>
    <div className="tether-shape-display">{shapes[currentShapeIndex]}</div>
    <div className="tether-modal-buttons">
      <button onClick={() => setShowReflection(true)}>Reflect</button>
      <button onClick={handleClose}>Return to Partner Mode</button>
    </div>
  </div>
</div>

      )}

      {showReflection && (
        <div className="tether-modal show">
          <div className="tether-modal-content">
            <h3>Reflection</h3>
            <p>What did you notice during this moment together?</p>
            <textarea
              value={reflectionText}
              onChange={(e) => setReflectionText(e.target.value)}
              placeholder="Write a short reflection..."
              rows={4}
              style={{ width: '100%', borderRadius: '8px', padding: '0.5rem' }}
            />
            <button onClick={handleReflectionSave}>Save Reflection</button>
          </div>
        </div>
      )}

      <div className="tether-controls-overlay">
        <div className="player-controls left">WASD — Player 1</div>
        {playerMode === 'dual' && (
          <div className="player-controls right">Arrow Keys — Player 2</div>
        )}
      </div>
    </div>
  );
}
}
