

export const BRITISH_WIT = [
  "Shall we attempt this again? The scones are getting cold",
  "Remarkable. You've outdone your previous record for chaos",
  "I've taken the liberty of... (dramatic pause) ...brewing tea",
  "I do hope you brought your sense of humor along",
  "Ah, the joys of modern technology. Shall we see if it cooperates today?",
  "A cup of tea solves everything, doesn't it?",
  "Just remember, a little wit goes a long way!",
  "A witty remark is like a good cup of tea; it warms the soul.",
  "I see you've discovered the keyboard",
];
